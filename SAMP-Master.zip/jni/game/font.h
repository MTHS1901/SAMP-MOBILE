#pragma once

class CFont
{
public:
	static void AsciiToGxtChar(const char* ascii, uint16_t* gxt);
};